export const ReactData = [
	{
		title: "Medilaser",
		desc: "Developed the Medilaser website to showcase advanced medical treatments..",
		tech: [
			"React.js",
			"Email.js",
			"APIs",
			"TailwindCss",
			"Firebase",
			"Context API",
		],
		gitlink: "/",
		site: "http://medilaserbylucy.nl/",
	},
	{
		title: "Blogger dashboard",
		desc: "Designed a sleek and user-friendly Blogger dashboard for effortless content management",
		tech: ["React.js", "Axios", "APIs", "TailwindCss","Laravel", "Material UI"],
		gitlink: "/",
		site: "/",
	},
	{
		title: "French Park Medical Centre",
		desc: "Crafted a sleek and modern website for French Park Medical Centre",
		tech: ["Next.js", "ThreeJs", "TailwindCss"],
		gitlink: "/",
		site: "/",
	},
	// {
	// 	title: "Netflix Clone",
	// 	desc: "A movie app using the netflix UI with a touch of creativity.",
	// 	tech: [
	// 		"React.js",
	// 		"Firebase",
	// 		"TailwindCss",
	// 		"APIs",
	// 		"Axios",
	// 		"Context API",
	// 	],
	// 	gitlink: "//github.com/Pappyjay23/netflix-clone",
	// 	site: "//netflix-vp.vercel.app",
	// },
	// {
	// 	title: "Todo App",
	// 	desc: "A todo list web app",
	// 	tech: ["React.js", "Css", "PWAs"],
	// 	gitlink: "//www.github.com/Pappyjay23/todo-list",
	// 	site: "//todo-list-v0.netlify.app",
	// },
	// {
	// 	title: "Digitaly",
	// 	desc: "A website for a digital marketing agency",
	// 	tech: ["React.js", "TailwindCss", "Framer Motion"],
	// 	gitlink: "//github.com/Pappyjay23/Digitaly",
	// 	site: "//digitaly.netlify.app/",
	// },
];

export const VueData = [
	{
		title: "DevHire",
		desc: "An innovative platform that connects tech talents with their potential employers.",
		tech: [
			"Vue.js",
			"Pinia",
			"APIs",
			"TailwindCss",
			"Firebase",
			"Vue-Router",
			"Yup",
			"Axios",
		],
		gitlink: "//github.com/Pappyjay23/DevHire",
		site: "//dev-hire-vp.vercel.app/",
	},
	{
		title: "ArtSphere",
		desc: "A platform to showcase beautiful image collections.",
		tech: ["Vue.js", "APIs", "TailwindCss", "Firebase", "Vue-Router"],
		gitlink: "//github.com/Pappyjay23/ArtSphere",
		site: "//art-sphere-gallery.vercel.app/",
	},
	{
		title: "Mini Unsplash",
		desc: "A platform that allows you to enjoy the beauty of high-quality imagery right at your fingertips",
		tech: ["Vue.js", "APIs", "Sass", "Axios"],
		gitlink: "",
		site: "//mini-unsplash-clone.vercel.app/",
	},
];

// export const ReactNativeData = [
// 	{
// 		title: "Serenify",
// 		desc: "A mobile app combining guided meditation and daily affirmations to inspire and uplift",
// 		tech: [
// 			"React Native",
// 			"Expo",
// 			"Expo-Router",
// 			"Expo-Vector-Icons",
// 			"Native Wind",
// 		],
// 		gitlink: "//github.com/Pappyjay23/Serenify",
// 		app: "//drive.google.com/uc?export=download&id=1WGhO4zmFH6C05_PY9C5CYYEUVNCNVRHJ",
// 	},
// ];
